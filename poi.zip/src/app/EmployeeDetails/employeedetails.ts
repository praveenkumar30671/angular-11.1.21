export class Employeedetails {
    id?:any;
    srccs:string;
    name: string;
    Id: number;
    empid: number;
    emailid: string;
    phonenumber: number;
    skill: string;
    
}
