export class Add {
    name: string;
    empid: number;
    emailid: string;
    Id: number;
    id?:any;
    srccs:string;
    phonenumber: number;
    skill: string;
}
