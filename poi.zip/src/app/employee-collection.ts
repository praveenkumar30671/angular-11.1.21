import { Employeedetails } from './EmployeesDetail/employeedetails';

export class EmployeeCollection {
    employees:Employeedetails[];
    employeeCount:number;
}
