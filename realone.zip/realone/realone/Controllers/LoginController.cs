﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Couchbase;
using Microsoft.AspNetCore.Mvc;
using realone.Interface;
using realone.model;
using realone.service;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Logging;
using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;







namespace realone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]



    public class LoginController : ControllerBase

    {
        private readonly ILoginService _Iservice;

        private readonly ILogger<LoginController> _logger;

        private readonly ApplicationSettings _appSettings;

        public LoginController(ILoginService Iservice, ILogger<LoginController> logger, IOptions<ApplicationSettings> appSettings)
        {
            this._logger = logger;
           
            this._Iservice = Iservice;
            _appSettings = appSettings.Value;
        }

        // GET: api/<LoginController>
        [HttpGet]
        [EnableQuery()]
        [AllowAnonymous]

        public async Task<LoginCollection> Get([FromQuery] Credentials credentials)


        {
            _logger.LogInformation("Can't get Login info");

            var couchClient = await _Iservice.initialize();
            var logindetails = await _Iservice.GetLoginDetails(couchClient, credentials);

            LoginCollection login = new LoginCollection();
            if (logindetails == null)
            {
                _logger.LogError("Error in getting Login details");
                return login;

            }
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, logindetails.id),

                    new Claim(ClaimTypes.Role, logindetails.logintype.ToString()),
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_appSettings.JWT_Secret)), SecurityAlgorithms.HmacSha256Signature)
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            logindetails.pwd = null;
            login.logindetails = logindetails;

            login.token = tokenHandler.WriteToken(securityToken);
            _logger.LogInformation(login.token);
            return login;



        }

        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]

        

        public async Task Post([FromBody] Logindetails form)
        {
            var couchClient = await _Iservice.initialize();
            var logindata = await _Iservice.PostLogin(couchClient, form);
            if (logindata != null)
            {
                _logger.LogInformation("Successfully posted");
            }
        }






    }
}

