﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using realone.model;
using realone.Interface;
using realone.Controllers;
using Microsoft.AspNetCore.Mvc;





namespace realone.Interface
{
    public interface ILoginService
    {
        Task<ICluster> initialize();
           
        Task<Logindetails> GetLoginDetails(ICluster cluster , Credentials credentials);

        Task<Logindetails> PostLogin(ICluster cluster,Logindetails form);
    }




}

