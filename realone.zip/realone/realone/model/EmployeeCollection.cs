﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace realone.model
{
    public class EmployeeCollection

    {
        public List<Empdetails> employees { get; set; }

        public int employeeCount { get; set; }

    }
}
