﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using realone.Interface;
using realone.model;
using Couchbase;
using Castle.Components.DictionaryAdapter;
using Couchbase.KeyValue;
using Microsoft.Extensions.Options;
using realone.Controllers;
using Microsoft.AspNetCore.Mvc;
using Polly; 
using Microsoft.Extensions.Logging;
using Couchbase.Core.Exceptions;








namespace realone.service
{
    public class Loginservice : ILoginService
    {
        private readonly ILogger<Loginservice> _logger;

        public Loginservice(ILogger<Loginservice> logger)
        {
            _logger = logger;
        }




        public async Task<Logindetails> GetLoginDetails(ICluster cluster, Credentials credentials)
        {
            try
            {


                var queryResult = await cluster.QueryAsync<Logindetails>("SELECT designation,id,username,pwd,logintype FROM loginDetails", new Couchbase.Query.QueryOptions());

                List<Logindetails> empList = new List<Logindetails>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }

                var employee = empList.Find(x => x.username == credentials.username && x.pwd == credentials.pwd);
            return employee;
            }
            catch (IndexFailureException)
            {
                _logger.LogError("Bucket not found");
                throw;
            }
        }




        public async Task<ICluster> initialize()
        {

            try
            {
                var policy = Policy.Handle<Exception>()
                   .WaitAndRetryAsync(2, count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {
                    _logger.LogInformation("Retrying the progress...");
                    await Retry();
                });


                return await Retry();


            }
            catch (AuthenticationFailureException)
            {
                _logger.LogError("Authentication error");
                throw;
            }


            
    
        }
        public async Task<ICluster> Retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Administrator", "Password");
            var bucket = await cluster.BucketAsync("LoginDetails");
            var collection = bucket.DefaultCollection();
            return cluster;
        }

        public async Task<Logindetails> PostLogin(ICluster cluster, Logindetails form)
        {
            try
            {
                var bucket = await cluster.BucketAsync("LoginDetails");
                var collection = bucket.DefaultCollection();
                var idvalue = form.id;
                await collection.InsertAsync(idvalue.ToString(), form);

                return null;
            }
            catch (IndexFailureException)
            {
                _logger.LogError("Bucket not found for LoginController");
                throw;
            }
        }
    }

}